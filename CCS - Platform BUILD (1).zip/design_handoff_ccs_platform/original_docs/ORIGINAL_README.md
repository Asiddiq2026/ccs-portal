# Handoff: CCS AR Oversight Platform (for Razlin Limited)

## Overview
CCS ("Comprehensive Compliance Solutions") is a compliance-operations platform licensed to **Razlin Limited (FCA principal firm, FRN 730805)** to oversee its appointed-representative (AR) network under SUP 12. It gives ARs a self-service portal to submit financial promotions / teasers / decks / research for Razlin sign-off (with document upload and an immutable audit trail), gives Razlin Compliance the registers and monitoring tools, and gives the SMF16/17 (Adnan Siddiq) a Sign-Off Queue that is the single egress point for anything leaving the platform. Seven headless "agents" automate the operational cycle (chase, consolidate, cross-check, draft notifications) but never send/file/finalise without human sign-off.

Active ARs: **SIX Financial Information UK, Drake Star UK, Codrington Associates** (plus one introducer and an onboarding pipeline). Acuvera, Arlington and Novel Vision are NOT ARs — do not reintroduce them.

## About the design files
The files in this bundle are **design references created in HTML** — a working front-end prototype that demonstrates the intended look, information architecture and interactions. They are **not production code to ship directly.** The task is to **recreate this design in a real, server-backed application** using the target stack's established patterns (React/Next recommended), replacing the in-file mock data with a database + API, and adding auth, document storage and the agent runtime. Where a framework choice is open, React + Next.js + Postgres on Azure fits the agent runtime cleanly.

## Fidelity
**High-fidelity.** Final colours, typography, spacing, copy and interactions are all present and should be recreated faithfully. Two complete themes are provided:
- `CCS AR Oversight Portal.html` — dark theme (charcoal / teal / lime).
- `CCS AR Oversight Portal Light.html` — light theme (white / ink / teal). **This is the preferred production theme.**

Both are the same application; build once and theme via CSS variables (see Design Tokens).

## Screens / views
The app is a single-page shell: sticky header + left sidebar nav + a `#view` main pane that swaps module HTML. ~25 modules, all data-driven from a config object per register. Key ones:

- **Oversight Dashboard** — network health ring (composite RAG across 11 dimensions), 4 KPI tiles, "Needs your attention" priority queue, upcoming-deadlines timeline, and an AR × 11-dimension RAG compliance matrix.
- **Financial Promotions (the AR submission channel)** — submission queue with type filter tabs (research / teasers / decks / marketing / advisory); each row shows ref, title, AR, type chip, COBS-risk bar, document count, status; actions Adopt / Reject / AI Review / View. A "+ Submit for adoption" modal captures identification, audience/distribution, a COBS 4 checklist, **drag-and-drop document upload (SHA-256 hashed)**, and reviewer notes. An **immutable Audit Trail** card logs every SUBMITTED / DOCS ATTACHED / AI REVIEW / CLARIFICATION / ADOPTED / REJECTED event; a per-submission detail modal shows its document manifest + filtered audit history. AI review calls Claude (currently client-side — MUST move server-side).
- **AR Register & Lifecycle, AR Agreements, Permissions & RAO Scope, Onboarding Pipeline** — SUP 12 lifecycle registers.
- **CF30 Returns** — quarterly digital return, NIL-by-default (12 sections), risk-based cadence; two-click NIL submission modal.
- **AR Risk Scoring** — 5-factor 1-3 model, live band recalculation (5-7 bi-annual / 8-11 quarterly / 12-15 quarterly+ad hoc).
- **CF30 Certification & Compliance Training** — SM&CR training & assessment, CPD 35h/yr, three-strike rule.
- Conduct registers: **Market Abuse/STOR, Research Distribution, PAD, Gifts & Entertainment, Conflicts, T&C/SM&CR**.
- People/financial crime: **AML, Data Breaches (ICO), SARs, Whistleblowing, Complaints, Breaches, Real-Time Monitoring, Attestations Hub, Regulatory Calendar, Manual Control Map, Policy Register, Forms & Declarations**.

## Interactions & behaviour
- **Routing:** `go(navEl)` sets `currentMod` and renders `MODULES[mod]()` into `#view`. `rerender()` re-renders current module after data change.
- **Registers** are rendered by a generic `renderTable(cfg)` from a `{cols,rows}` config; editable registers support add-row (generic modal driven by column config) and delete-row.
- **FP flow:** submit -> row added `status:'pending'` + audit events logged -> Adopt/Reject changes status and logs -> AI Review streams a Claude verdict into an inline panel.
- **Uploads:** `filesPicked()` hashes each file with `crypto.subtle.digest('SHA-256')` and renders removable file pills; on submit the docs attach to the record and are logged.
- **Toasts** on every action; **CSV export** on every register + the audit trail.
- **Persistence (prototype only):** `localStorage` key `ccs_ar_portal_v3`. In production this is the database — remove localStorage.

## State management
Prototype holds state in module-scope `const` arrays (`FP`, `AUDIT`, `ATTEST`, `CAL`, `CF30_RISK`, and the `REG_*` register objects), keyed for editing in `DATASETS`. **In production every one of these becomes a database table**, read/written via the API. Auth context (role + AR scope) must gate what data is fetched and what actions render.

## Production requirements (beyond the prototype)
1. **Backend:** Postgres (table per register), an API exposing `query_database` / `write_register_entry` (writes land 'pending sign-off') / `enqueue_for_signoff`, plus UI CRUD.
2. **Auth:** SSO (Entra/Okta); three roles — AR (own firm only, row-level security), Razlin Compliance (network read + drafting), SMF16/17 (sign-off authority). AR-facing output carries Razlin branding only; CCS marks are internal.
3. **Documents + audit:** object storage with WORM/immutability; SHA-256 recorded server-side; append-only audit table; retention docs/audit 6 yrs, agent logs 7 yrs.
4. **Server-side AI:** move the FP AI-review fetch off the browser to a server endpoint with a vaulted key.
5. **Agent runtime (Claude Agent SDK, headless):** seven agents —
   - CRON: `agent-quarterly-cycle` (daily 06:00), `agent-anomaly` (nightly 02:00), `agent-cpd-tracker` (daily 06:00)
   - WEBHOOK: `agent-consolidator` (on submitted return), `agent-notification-drafter` (on flagged event)
   - ON-DEMAND: `agent-pre-meeting-prep`, `agent-evidence-packer`
   Each has a fixed prompt, a **tool whitelist**, and a typed JSON output schema. Withhold `send-email` / `file-regulatory` / `persist-final` from ALL agents — the only egress is `enqueue_for_signoff`. Fail-closed to an OPERATOR REVIEW flag on any error/ambiguity. Deterministic date/threshold arithmetic runs in code, not the model.

## Design tokens (light theme — preferred)
- Ink text `#101828`; secondary `#4E576A`; muted `#8A93A6`.
- Surfaces: app bg `#F3F5F8`; cards `#FFFFFF`; subtle `#F5F7FA`; row alt `#EDF0F5`.
- Borders `#E3E7EE` / `#D3D9E4`.
- Accent teal `#0891B2` (hover `#0E7490`, deep `#155E75`); olive/lime `#65A30D` / `#4D7C0F`.
- Status: green `#15803D`, amber `#B45309`, red `#B91C1C`, blue `#1D4ED8`, purple `#7E22CE` (each with an ~8% tint bg).
- Dark-theme equivalents are the `:root` block at the top of the dark file.
- Type: **Sora** (display/headings) + **Manrope** (body) + **JetBrains Mono** (labels, refs, data) in the portal; the light theme also uses these. Radii ~8-12px; shadow `0 6px 24px rgba(16,24,40,.09)`.
- Spacing: card padding 15-20px; table cell 12-16px; nav item 8-9px/22px.

## Assets
No external image assets — the CCS "shard" logo is inline SVG in the header. Fonts load from Google Fonts. Recreate the logo as an SVG component; use the existing brand system if Razlin/CCS supplies one.

## Files
- `CCS AR Oversight Portal Light.html` — full app, light theme (preferred production reference).
- `CCS AR Oversight Portal.html` — full app, dark theme.
- `CCS Architecture One-Pager.html` — system architecture (open in browser; print to PDF).
- `CCS Go-Live Checklist.html` — sequenced build-to-live plan with gates.
- Agent specifications (behaviour, triggers, tools, output schemas, test cases) are in the source spec `CCS-AGENT-SPECS-001`; mirror those schemas exactly.

## Not in scope for the front-end / cautions
- Do NOT ship the HTML as-is or keep data in `localStorage`.
- Do NOT keep the Anthropic call client-side.
- Do NOT let any agent gain a send/file/persist tool — sign-off is the only egress.
- Keep the AR roster to SIX, Drake Star, Codrington.
